import mx.unam.fes.dinamico.ListaDoblementeEnlazada;

public class Ejercicio3 {

    public static void main(String[] args) {
        ListaDoblementeEnlazada<String> listaDoble = new ListaDoblementeEnlazada<>();

        System.out.println("--- Demostración de Lista Doblemente Enlazada ---");
        
        System.out.println("1. Agregando datos a la cabeza y a la cola...");
        listaDoble.agregarCabeza("Inicio");
        listaDoble.agregarCola("Medio");
        listaDoble.agregarCola("Fin");
        listaDoble.imprimir();
        
        System.out.println("\n\n2. Insertando un dato en el índice 1...");
        listaDoble.insetarEnIndice("Nuevo Medio", 1);
        listaDoble.imprimir();
        
        System.out.println("\n\n3. Eliminando la cola...");
        listaDoble.eliminarCola();
        listaDoble.imprimir();
        
        System.out.println("\n\n4. Eliminando la cabeza...");
        listaDoble.eliminarCabeza();
        listaDoble.imprimir();
        System.out.println();
    }
}
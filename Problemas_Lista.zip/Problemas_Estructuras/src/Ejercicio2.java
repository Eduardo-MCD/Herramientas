import mx.unam.fes.dinamico.ListaSimple;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Ejercicio2 {

    public static void main(String[] args) {
        ListaSimple<Integer> listaFiltrada = new ListaSimple<>();
        String nombreArchivo = "numeros_aleatorios.txt";

        System.out.println("Leyendo archivo y filtrando números (30-150)...");
        
        // 1. Leer el archivo y extraer los números
        try (BufferedReader br = new BufferedReader(new FileReader(nombreArchivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                // Separamos la fila por las comas
                String[] numerosString = linea.split(",");
                
                for (String numStr : numerosString) {
                    if (!numStr.trim().isEmpty()) {
                        int numero = Integer.parseInt(numStr.trim());
                        
                        // Si está en el rango solicitado, lo guardamos en la lista
                        if (numero >= 30 && numero <= 150) {
                            listaFiltrada.agregarCola(numero);
                        }
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Ocurrió un error al leer el archivo: " + e.getMessage());
            return;
        }

        System.out.println("Generando reporte de repeticiones...\n");
        
        // 2. Contar las repeticiones extraídas de la lista
        // Usamos un arreglo simple de tamaño 151 para llevar el conteo
        int[] repeticiones = new int[151]; 

        while (!listaFiltrada.isvacia()) {
            int numero = listaFiltrada.eliminarDeCabeza();
            repeticiones[numero]++;
        }

        // 3. Imprimir el reporte con el formato solicitado
        for (int i = 30; i <= 150; i++) {
            if (repeticiones[i] > 0) {
                // Formato exacto que pidió el profesor
                System.out.println(i + "- salió " + repeticiones[i] + " veces.");
            }
        }
    }
}
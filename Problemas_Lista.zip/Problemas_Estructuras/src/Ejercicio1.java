import mx.unam.fes.dinamico.ListaSimple;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

public class Ejercicio1 {

    public static void main(String[] args) {
        // Inicializamos la lista importada .jar
        ListaSimple<Integer> listaNumeros = new ListaSimple<>();
        Random random = new Random();

        System.out.println("Generando 10,000 números aleatorios...");
        // Generamos los 10000 números enteros aleatorios
        for (int i = 0; i < 10000; i++) {
            // Se define el rango de 1 a 300
            int numeroAleatorio = random.nextInt(300) + 1; 
            listaNumeros.agregarCola(numeroAleatorio);
        }

        String nombreArchivo = "numeros_aleatorios.txt";
        System.out.println("Escribiendo los números en el archivo...");
        
        try (PrintWriter writer = new PrintWriter(new FileWriter(nombreArchivo))) {
            int contadorFila = 0;

            // Extraemos los datos de la lista hasta que quede vacía
            while (!listaNumeros.isvacia()) {
                Integer numero = listaNumeros.eliminarDeCabeza();
                writer.print(numero);
                contadorFila++;

                // Separamos por comas siempre y cuando no sea el final de la fila
                if (contadorFila < 1000 && !listaNumeros.isvacia()) {
                    writer.print(",");
                }

                // Al llegar a 1000 números en una fila, hacemos un salto de línea
                if (contadorFila == 1000) {
                    writer.println();
                    contadorFila = 0;
                }
            }
            System.out.println("Archivo '" + nombreArchivo + "' creado con éxito en la raíz del proyecto.");
            
        } catch (IOException e) {
            System.out.println("Ocurrió un error al escribir el archivo: " + e.getMessage());
        }
    }
}
